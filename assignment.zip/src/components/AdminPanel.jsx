import React, { useState, useEffect } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { useLocation, useNavigate } from "react-router-dom";
import axios from "axios";
import "../styles/AdminPanel.css";
import ProfileForm from "../components/ProfileForm";

const OPENCAGE_API_KEY = "64517fde6f8145639d35a96ad188bcbd";

const AdminPanel = () => {
    const [profiles, setProfiles] = useState([]);
    const [selectedProfile, setSelectedProfile] = useState(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isEditMode, setIsEditMode] = useState(false);
    const [mapVisible, setMapVisible] = useState(false);
    const [searchQuery, setSearchQuery] = useState("");
    const [loading, setLoading] = useState(false);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [profileToDelete, setProfileToDelete] = useState(null);
    const navigate = useNavigate();
    const location = useLocation();

    useEffect(() => {
        const fetchProfiles = async () => {
            setLoading(true);
            try {
                const savedProfiles = JSON.parse(localStorage.getItem("profiles")) || [];
                setProfiles(savedProfiles);
            } catch (error) {
                console.error("Error fetching profiles:", error);
            } finally {
                setLoading(false);
            }
        };
        fetchProfiles();
    }, []);

    useEffect(() => {
        handleCloseMap();
    }, [location.pathname]);

    const openModal = (profile = null) => {
        setSelectedProfile(profile);
        setIsEditMode(!!profile);
        setIsModalOpen(true);
    };

    const closeModal = () => {
        setSelectedProfile(null);
        setIsModalOpen(false);
    };

    const addProfile = (newProfile) => {
        const profileWithId = { ...newProfile, id: Date.now() };
        localStorage.setItem("profiles", JSON.stringify([...profiles, profileWithId]));
        setProfiles([...profiles, profileWithId]);
        closeModal();
    };

    const updateProfile = (updatedProfile) => {
        const updatedProfiles = profiles.map((profile) =>
            profile.id === updatedProfile.id ? updatedProfile : profile
        );
        localStorage.setItem("profiles", JSON.stringify([...updatedProfiles]));
        setProfiles(updatedProfiles);
        closeModal();
    };

    const confirmDeleteProfile = (profile) => {
        setProfileToDelete(profile);
        setIsDeleteModalOpen(true);
    };

    const deleteProfile = async () => {
        setLoading(true);
        try {
            const updatedProfiles = profiles.filter((profile) => profile.id !== profileToDelete.id);
            localStorage.setItem("profiles", JSON.stringify(updatedProfiles));
            setProfiles(updatedProfiles);
        } catch (error) {
            console.error("Error deleting profile:", error);
        } finally {
            setLoading(false);
            setIsDeleteModalOpen(false);
        }
    };

    const viewProfileDetails = (profile) => {
        setSelectedProfile(profile);
        setMapVisible(true);
    };

    const handleCloseMap = () => {
        setMapVisible(false);
        setSelectedProfile(null);
    };

    useEffect(() => {
        if (mapVisible) {
            initializeMap();
        }
    }, [mapVisible, selectedProfile]);

    return (
        <div className="admin-panel">
            <div className="header">
                <h1>Admin Panel</h1>
                <button className="add-btn" onClick={() => openModal()}>Add Profile</button>
            </div>

            <input
                type="text"
                placeholder="Search profiles..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="search-bar"
            />

            {loading ? (
                <div className="loading">Loading...</div>
            ) : (
                <table className="profile-table">
                    <thead>
                        <tr>
                            <th>Sr No.</th>
                            <th>Profile Img</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Description</th>
                            <th>Address</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {profiles.map((profile, index) => (
                            <tr key={profile.id}>
                                <td>{index + 1}</td>
                                <td>
                                    <img src={profile.imageFile} alt="Profile" className="profile-img" />
                                </td>
                                <td>{profile.name}</td>
                                <td>{profile.email}</td>
                                <td>{profile.description}</td>
                                <td>{profile.address}</td>
                                <td>
                                    <button className="view-btn" onClick={() => navigate(`/profile/${profile.id}`)}>View</button>
                                    <button className="edit-btn" onClick={() => openModal(profile)}>Edit</button>
                                    <button className="delete-btn" onClick={() => confirmDeleteProfile(profile)}>Delete</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}

            {isModalOpen && (
                <div className="modal">
                    <div className="modal-content">
                        <ProfileForm
                            onSubmit={isEditMode ? updateProfile : addProfile}
                            profile={selectedProfile}
                            closeModal={closeModal}
                        />
                    </div>
                </div>
            )}

            {isDeleteModalOpen && (
                <div className="modal">
                    <div className="modal-content">
                        <h2>Confirm Deletion</h2>
                        <p>Are you sure you want to delete this profile?</p>
                        <button className="cancel-btn" onClick={() => setIsDeleteModalOpen(false)}>Cancel</button>
                        <button className="confirm-delete-btn" onClick={deleteProfile}>Delete</button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default AdminPanel;
